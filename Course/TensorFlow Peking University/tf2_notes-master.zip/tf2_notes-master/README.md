# tf2_notes

人工智能实践：Tensorflow笔记
https://www.icourse163.org/learn/PKU-1002536002

class4自制数据集数据文件
https://gitee.com/jlfff/tf_studynotes_2/releases/v.001
